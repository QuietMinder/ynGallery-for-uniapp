<template>
	<view class="content"  :style="{'min-height':sh+'px'}">				   

			<view >
				  <!--  -->
				  <ynGallery  					          
					  :galleryheight="165" 
					   bkstart="#000000"                     
					   bkend="#000000" 							  
					  :imgviewwidth="85" 
					  :imgviewheight="105"
					  :showbadge="true"
					   badegtype="trian"
					   badegwidth="25"
					   badegheight="25"
					  :showdec="true"
					  :images="testimgs" 
					  @clickimg="onclickimg"
					  >   
				 </ynGallery>
				 
				 
				 <text style="font-size: 15px;">							
					序:{{Msg}} 
				 </text>		
			</view>    			
			
			<view class="" style="background-color:white">
				<image class="logo" src="/static/logo.png"></image>
				<view>
					 <text class="title">{{title}}</text>
				</view>					
			</view>

	</view>
</template>

<script>
	import ynGallery from 'components/YnComponents/ynGallery/ynGallery.vue'

	export default {
		components: {		
			ynGallery,
		},			
		data() {
			return {
				 sh:0,
				 Msg  :"0",
				 title: 'Hello',
				 // 画廊示例数据
				 testimgs :[{url:"http://p0.meituan.net/movie/fc4dd6cd0c6f7db566a128cc05c475355664427.jpg@170w_235h_1e_1c"},
						    {url:"http://p0.meituan.net/movie/616cd50a33550a9225ac781e52d14ae54967551.jpg@170w_235h_1e_1c"},
							{url:"http://p0.meituan.net/movie/616cd50a33550a9225ac781e52d14ae54967551.jpg@170w_235h_1e_1c"},
							{url:"http://p0.meituan.net/movie/fc4dd6cd0c6f7db566a128cc05c475355664427.jpg@170w_235h_1e_1c"},
							{url:"http://p0.meituan.net/movie/fc4dd6cd0c6f7db566a128cc05c475355664427.jpg@170w_235h_1e_1c"},
							{url:"http://p0.meituan.net/movie/616cd50a33550a9225ac781e52d14ae54967551.jpg@170w_235h_1e_1c"}],				
			}
		},
		onLoad() {
		 this.sh=this.GetScreenHeight();
		 this.setimgs();
		   // console.log(this.testimgs);
		},
		
		methods: {
		  onclickimg(imgviewobj){
			
			if (imgviewobj.index!=undefined)
			    
				this.Msg= `${imgviewobj.index}`;
			
		  },
		  setimgs(){
			 
			  for (let i in this.testimgs){				  
				  this.testimgs[i].dominant=this.retcolor();   //随机主色
				  this.testimgs[i].dec=i;                      //描述  
				  this.testimgs[i].badeg=i;                    //角标文字
				  this.testimgs[i].badegcolor=(i % 2)==0?'red':'LimeGreen';   //角标随机颜色
			  }
			 
		  },
          GetScreenHeight(){
         			 let sh = uni.getSystemInfoSync().windowHeight;
         			 return sh;
         			 console.log(sh)
         } ,		  
		  retcolor(){
			let color='#' + ('00000' + (Math.random() * 0x1000000 << 0).toString(16)).substr(-6);
			return color;
		  }		
		}
	}
</script>

<style>
	.content {
		text-align: center;
		height: 400upx;
	}
    .logo{
		height: 100upx;
        width: 100upx;
        margin-top: 350upx;
		margin-bottom: 10upx;
		border-radius: 50upx;
    }
	.title {
		font-size: 36upx;
		color: #8f8f94;
	}
</style>
